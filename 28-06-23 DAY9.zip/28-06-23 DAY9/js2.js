var a= ("niraj", "buha");
document.write(a instanceof Array);

document.write("<br/>")

class Rectangle {
    constructor(height, width) {
        this.height = height;
        this.width = width;
        
    }
}
var R = new Rectangle(10,20);
document.write(R instanceof Rectangle);

document.write("<br/>");

document.write(R.height+R.width);
let s1 = "niraj";
let s2 = "buha";
let s3 = s1 + " " + s2;
document.write("<br/>",s3);